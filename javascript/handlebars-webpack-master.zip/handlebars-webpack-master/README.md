This is simply a working example of how to integrate the Handlebars templating solution into a typical webpack workflow.

# You Need webpack First!
Make sure you have webpack installed globally on your machine.

` npm install webpack -g`

For additional help see [the official webpack site](https://webpack.github.io/).

After cloning this repo and CD'ing into the project folder be sure to run `npm install`

Then, whenever you want to bundle everything up simply run `webpack` 

Celebrate.
